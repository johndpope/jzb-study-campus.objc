#import <UIKit/UIKit.h>


@interface BenchmarkIPhoneViewController : UIViewController
{
	
}

@end

