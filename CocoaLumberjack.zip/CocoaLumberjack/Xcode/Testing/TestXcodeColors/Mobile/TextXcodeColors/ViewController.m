#import "ViewController.h"


@implementation ViewController

@synthesize label;

@end
