#import <UIKit/UIKit.h>


@interface RegisteredLoggingTestViewController : UIViewController

@end
