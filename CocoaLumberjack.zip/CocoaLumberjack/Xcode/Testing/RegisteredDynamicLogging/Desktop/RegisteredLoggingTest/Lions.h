#import <Foundation/Foundation.h>


@interface Lions : NSObject

+ (void)logStuff;

@end
