#import <Foundation/Foundation.h>
#import "DDLog.h"


@interface MyContextFilter : NSObject <DDLogFormatter>
{
}

@end
