#import <Foundation/Foundation.h>
#import "DDLog.h"


@interface TestFormatter : NSObject <DDLogFormatter>

@end
