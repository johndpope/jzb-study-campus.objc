#import <Foundation/Foundation.h>
#import "DDLog.h"


@interface SlowLogger : DDAbstractLogger <DDLogger>


@end
