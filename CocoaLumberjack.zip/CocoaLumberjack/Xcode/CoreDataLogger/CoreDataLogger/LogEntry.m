#import "LogEntry.h"


@implementation LogEntry

@dynamic context;
@dynamic level;
@dynamic message;
@dynamic timestamp;

@end
