#import <Cocoa/Cocoa.h>


@interface Stuff : NSObject {

}

+ (void)doStuff;

@end
